"""
分形相关操作封装
"""
from .LSystem import Pen
from .IFS import IFS
